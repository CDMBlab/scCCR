

from keras.layers import GaussianNoise, Dense, Activation


class Encoder():
    def __init__(self, dims, noise_sd=1.5, init='glorot_uniform', act='relu'):
        self.dims = dims
        self.n_stacks = len(self.dims) - 1  # 堆栈数
        self.init = init
        self.noise_sd = noise_sd
        self.act = act

    def __call__(self, inputs):
        self.h = inputs
        for i in range(self.n_stacks - 1):  #编码器，输入1000，隐藏层256，64
            self.h = Dense(units=self.dims[i + 1], kernel_initializer=self.init, name='encoder_%d' % i)(self.h)#输出层为dim[i+1]，输入为self.h
            self.h = GaussianNoise(self.noise_sd, name='noise_%d' % i)(self.h)  # add Gaussian noise
            self.h = Activation(self.act)(self.h)#激活函数
        outputs = self.h
        return outputs



class Decoder():
    def __init__(self, dims, init='glorot_uniform', act='relu'):
        self.dims = dims
        self.n_stacks = len(self.dims) - 1  # 堆栈数
        self.init = init
        self.act = act

    def __call__(self, inputs):
        self.h = inputs
        for i in range(self.n_stacks - 1, 0, -1):  # 解码器【64，256】
            self.h = Dense(units=self.dims[i], activation=self.act, kernel_initializer=self.init,
                           name='decoder_%d' % i)(self.h)
        outputs = self.h
        return outputs