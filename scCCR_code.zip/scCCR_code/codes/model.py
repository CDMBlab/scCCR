
import tensorflow as tf
import keras.backend as K

from layers import *


MeanAct = lambda x: tf.clip_by_value(K.exp(x), 1e-5, 1e6)
DispAct = lambda x: tf.clip_by_value(tf.nn.softplus(x), 1e-4, 1e4)

class scCCR():
    def __init__(self, name, dataname, dims, cluster_num, noise_sd=1.5, mode="cdec",
                 init='glorot_uniform', act='relu', distrib="ZINB"):
        self.name = name
        self.dataname = dataname  # 数据文件名
        self.dims = dims  # 维度
        self.cluster_num = cluster_num  # 聚类数
        self.noise_sd = noise_sd  # 高斯噪声
        self.init = init  # 初始化
        self.act = act  # 激活函数
        self.mode = mode  # cdec模型
        self.distrib = distrib  # ZINB分布

        self.n_stacks = len(self.dims) - 1  # 堆栈数
        self.x = tf.placeholder(dtype=tf.float32, shape=(None, self.dims[0]))
        self.y = tf.placeholder(dtype=tf.float32, shape=(None, self.cluster_num))  # 输出y
        self.label_vec = tf.placeholder(dtype=tf.float32, shape=(None,))  # 标签向量
        self.mask_vec = tf.placeholder(dtype=tf.float32, shape=(None,))  # 掩码向量
        self.x_count = tf.placeholder(dtype=tf.float32, shape=(None, self.dims[0]))  # 未标准化数据x
        self.sf_layer = tf.placeholder(dtype=tf.float32, shape=(None, 1))  # sf层
        self.clusters = tf.get_variable(name=self.dataname + "/clusters_rep", shape=[self.cluster_num, self.dims[-1]],
                                        # shape为【7，32】
                                        dtype=tf.float32,
                                        initializer=tf.glorot_uniform_initializer())  # tf.get_variable：使用这些参数获取现有变量或创建一个新变量。该函数的作用是创建新的tensorflow变量
        # 由一个均匀分布（uniform distribution)来初始化数据
        with tf.compat.v1.variable_scope(self.name):
            self.build()
    def build(self):
        self.inputs = GaussianNoise(self.noise_sd, name='input_noise')(self.x)
        self.encoder_hidden = Encoder(self.dims)(self.inputs)
        self.latent = Dense(units=self.dims[-1], kernel_initializer=self.init, name='encoder_hidden')(self.encoder_hidden)  # 潜在空间，32个神经元
        self.discriminate = Dense(units=self.cluster_num, activation=tf.nn.softmax, kernel_initializer=self.init,
                                  name='classification_layer')(self.latent)  # 判别器，激活函数softmax
        self.decoder_out = Decoder(self.dims)(self.latent)


        if self.distrib == "ZINB":
            self.pi = Dense(units=self.dims[0], activation='sigmoid', kernel_initializer=self.init, name='pi')(self.decoder_out)#ZINB分布的零膨胀参数
            self.disp = Dense(units=self.dims[0], activation=DispAct, kernel_initializer=self.init, name='dispersion')(self.decoder_out)#ZINB分布的色散参数
            self.mean = Dense(units=self.dims[0], activation=MeanAct, kernel_initializer=self.init, name='mean')(self.decoder_out)#ZINB分布的平均参数

        elif self.distrib == "NB":
            self.disp = Dense(units=self.dims[0], activation=DispAct, kernel_initializer=self.init, name='dispersion')(self.decoder_out)
            self.mean = Dense(units=self.dims[0], activation=MeanAct, kernel_initializer=self.init, name='mean')(self.decoder_out)
