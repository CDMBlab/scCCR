# -*- coding:utf-8 -*-
"""
作者：QinBaojuan
日期：2023年08月日
"""
from preprocess import *
import tensorflow as tf
import keras.backend as K
import tensorflow_probability as tfp

EPSILON = 1E-9
DEBUG_MODE = False

def cdist(X, Y):
    xyT = X @ tf.transpose(Y)
    x2 = tf.reduce_sum(X**2, axis=1, keepdims=True)
    y2 = tf.reduce_sum(Y**2, axis=1, keepdims=True)
    d = x2 - 2 * xyT + tf.transpose(y2)
    return d

def kernel_from_distance_matrix(dist, rel_sigma, min_sigma=EPSILON):

    # `dist` can sometimes contain negative values due to floating point errors, so just set these to zero.
    dist = tf.nn.relu(dist)
    # dist = relu(dist)
    sigma2 = rel_sigma * tfp.stats.percentile(dist, 50.0)

    # Disable gradient for sigma
    # sigma2 = sigma2.detach()
    sigma2 = tf.where(sigma2 < min_sigma, tf.fill(tf.shape(sigma2), min_sigma), sigma2)
    k = tf.exp(- dist / (2 * sigma2))
    return k
#
def vector_kernel(x, rel_sigma=0.15):
    return kernel_from_distance_matrix(cdist(x, x), rel_sigma)

def hidden_kernel(net, cfg):
    return vector_kernel(net.hidden, cfg.rel_sigma)

def triu(X):
    # Sum of strictly upper triangular part
    inputs = tf.diag_part(X)
    matrix = tf.matrix_diag(inputs)
    s = X - matrix

    return tf.reduce_sum(tf.linalg.band_part(s, num_lower=0, num_upper=-1))

def _atleast_epsilon(X, eps=EPSILON):
    """
    Ensure that all elements are >= `eps`.

    :param X: Input elements
    :type X: th.Tensor
    :param eps: epsilon
    :type eps: float
    :return: New version of X where elements smaller than `eps` have been replaced with `eps`.
    :rtype: th.Tensor
    """
    return tf.where(X < eps, tf.fill(tf.shape(X), eps), X)
def d_cs(A, K, n_clusters):
    """
    Cauchy-Schwarz divergence.

    :param A: Cluster assignment matrix
    :type A:  tf.Tensor
    :param K: Kernel matrix
    :type K: tf.Tensor
    :param n_clusters: Number of clusters
    :type n_clusters: int
    :return: CS-divergence
    :rtype: tf.Tensor
    """
    nom = tf.transpose(A) @ K @ A
    dnom_diag = tf.linalg.diag_part(nom)
    dnom_squared = tf.expand_dims(dnom_diag, -1) @ tf.expand_dims(dnom_diag, 0)

    nom = _atleast_epsilon(nom)
    dnom_squared = _atleast_epsilon(dnom_squared, eps=EPSILON**2)

    d = 2 / (n_clusters * (n_clusters - 1)) * triu(nom / tf.sqrt(dnom_squared))
    return d

def _nan2zero(x):#tf.zeros_like创建一个所有元素都设置为零的张量.
    return tf.where(tf.is_nan(x), tf.zeros_like(x), x)#tf.where还有一个用法，tf.where(input, a,b)，其中a，b均为尺寸一致的tensor，实现a中对应input中true的位置的元素值不变，其余元素由b中对应位置元素替换。


def _nan2inf(x):
    return tf.where(tf.is_nan(x), tf.zeros_like(x)+np.inf, x)


def _nelem(x):
    nelem = tf.reduce_sum(tf.cast(~tf.is_nan(x), tf.float32))#tf.is_nan查找指定张量输入的NaN元素，对于NaN元素，它返回true；对于除NaN之外的元素，它返回false。
    return tf.cast(tf.where(tf.equal(nelem, 0.), 1., nelem), x.dtype)#tf.where()返回一个布尔张量中真值的位置。对于非布尔型张量，非0的元素都判为True

def _reduce_mean(x):
    nelem = _nelem(x)
    x = _nan2zero(x)
    return tf.divide(tf.reduce_sum(x), nelem)


def NB(theta, y_true, y_pred, mask = False, debug = False, mean = False):#NB分布
    eps = 1e-10
    scale_factor = 1.0
    y_true = tf.cast(y_true, tf.float32)# tf.cast数据类型转换
    y_pred = tf.cast(y_pred, tf.float32) * scale_factor
    if mask:
        nelem = _nelem(y_true)
        y_true = _nan2zero(y_true)
    theta = tf.minimum(theta, 1e6)#返回x和y的最小值(即x < y ?x: y)。
    t1 = tf.lgamma(theta + eps) + tf.lgamma(y_true + 1.0) - tf.lgamma(y_true + theta + eps)#tf.lgamma对于正数，此函数为张量中的每个元素计算 log((input - 1)!)。lgamma(5) = log((5-1)!) = log(4!) = log(24) = 3.1780539
    t2 = (theta + y_true) * tf.log(1.0 + (y_pred / (theta + eps))) + (y_true * (tf.log(theta + eps) - tf.log(y_pred + eps)))
    if debug:
        assert_ops = [tf.verify_tensor_all_finite(y_pred, 'y_pred has inf/nans'),
                      tf.verify_tensor_all_finite(t1, 't1 has inf/nans'),
                      tf.verify_tensor_all_finite(t2, 't2 has inf/nans')]
        with tf.control_dependencies(assert_ops):
            final = t1 + t2
    else:
        final = t1 + t2
    final = _nan2inf(final)
    if mean:
        if mask:
            final = tf.divide(tf.reduce_sum(final), nelem)
        else:
            final = tf.reduce_mean(final)
    return final


def ZINB(pi, theta, y_true, y_pred, ridge_lambda, mean = True, mask = False, debug = False):#ZINB分布
    eps = 1e-10
    scale_factor = 1.0
    nb_case = NB(theta, y_true, y_pred, mean=False, debug=debug) - tf.log(1.0 - pi + eps)
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32) * scale_factor
    theta = tf.minimum(theta, 1e6)

    zero_nb = tf.pow(theta / (theta + y_pred + eps), theta)
    zero_case = -tf.log(pi + ((1.0 - pi) * zero_nb) + eps)
    result = tf.where(tf.less(y_true, 1e-8), zero_case, nb_case)
    ridge = ridge_lambda * tf.square(pi)
    result += ridge
    if mean:
        if mask:
            result = _reduce_mean(result)
        else:
            result = tf.reduce_mean(result)

    result = _nan2inf(result)
    return result

def cross_entropy_dec(hidden, cluster, alpha = 1.0):    #cluster表示聚类中心
    dist = K.sum(K.square(K.expand_dims(hidden, axis=1) - cluster), axis=2) #expand_dims(x, dim=-1)在下标为dim的轴上增加一维， square：平方,dist表示zi-uk的平方和，
    q = 1.0 / (1.0 + dist / alpha) ** ((alpha + 1.0) / 2.0) #dec软分配（t分布）
    q = q / tf.reduce_sum(q, axis=1, keepdims=True)
    p = q ** 2 / tf.reduce_sum(q, axis=0)
    p = p / tf.reduce_sum(p, axis=1, keepdims=True)
    crossentropy = -p * tf.log(tf.clip_by_value(q, 1e-10, 1.0)) - (1 - p) * tf.log(tf.clip_by_value(1 - q, 1e-10, 1.0)) #L2t
    return dist, crossentropy


def dec(hidden, cluster, alpha = 1.0):
    dist = K.sum(K.square(K.expand_dims(hidden, axis=1) - cluster), axis=2)
    q = 1.0 / (1.0 + dist / alpha) ** ((alpha + 1.0) / 2.0)
    q = q / tf.reduce_sum(q, axis=1, keepdims=True)
    p = q ** 2 / tf.reduce_sum(q, axis=0)
    p = p / tf.reduce_sum(p, axis=1, keepdims=True)
    kl = p * tf.log(tf.clip_by_value(p, 1e-10, 1.0)) - p * tf.log(tf.clip_by_value(q, 1e-10, 1.0))
    return dist, kl