
from loss import *

class Optimizer():
    def __init__(self, model, alpha, beta, gamma, delta, learning_rate, constraint = True, DDC_constraint = True):
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.learning_rate = learning_rate
        self.constraint = constraint
        self.DDC_constraint = DDC_constraint


        output = model.mean * tf.matmul(model.sf_layer, tf.ones((1, model.mean.get_shape()[1]), dtype=tf.float32))
        if model.distrib == "ZINB":
            self.ZINB_loss = ZINB(model.pi, model.disp, model.x_count, output, ridge_lambda=1.0)  # ZINB损失
            # Ld,去噪损失
            self.pre_loss = self.ZINB_loss
        elif model.distrib == "NB":
            self.NB_loss = NB(model.disp, model.x_count, output, mask=False, debug=False, mean=True)
            self.pre_loss = self.NB_loss

        softmax_mat = -model.y * tf.log(tf.clip_by_value(model.discriminate, 1e-10,1.0))  # 判别结构相似性正则化，tf.clip_by_value(A, min, max)：输入一个张量A，把A中的每一个元素的值都压缩在min和max之间。小于min的让它等于min，大于max的元素的值等于max。
        # Ls1
        self.softmax_loss = tf.reduce_sum(softmax_mat)

        label_mat = tf.reshape(model.label_vec, [-1, 1]) - tf.reshape(model.label_vec, [1, -1])
        label_mat = tf.cast(tf.equal(label_mat, 0.), tf.float32)  # 标签矩阵
        mask_mat = tf.matmul(tf.reshape(model.mask_vec, [-1, 1]), tf.reshape(model.mask_vec, [1, -1]))  # 掩码矩阵
        normalize_discriminate = tf.nn.l2_normalize(model.discriminate, axis=1)  # L2范数
        similarity = tf.matmul(normalize_discriminate,
                                    tf.transpose(normalize_discriminate))  # 相似性矩阵，tf.transpose转置，tf.matmul相乘
        self.pos = tf.exp(similarity)
        self.neg = tf.reduce_sum(mask_mat * (1 - label_mat) * tf.exp(similarity), axis=1)
        self.neg = tf.where(tf.equal(self.neg, 0), tf.ones_like(self.neg), self.neg)

        kl_loss = - mask_mat * label_mat * tf.log(tf.clip_by_value(self.pos / self.neg, 1e-10, 1.0))
        self.cross_entropy = tf.reduce_mean(kl_loss)

        if model.mode == "cdec":
            self.latent_dist1, latent_dist2 = cross_entropy_dec(model.latent, model.clusters)#self.clusters【7，32】：参数？ self.latent【？，32】  self.latent_dist1为dist self.latent_dist2为lt1损失
        elif model.mode == "dec":
            self.latent_dist1, latent_dist2 = dec(model.latent, model.clusters)
        #Lt
        self.kmeans_loss = tf.reduce_mean(tf.reduce_sum(latent_dist2, axis=1))

        K = vector_kernel(model.latent)
        self.DDC1 = d_cs(model.discriminate, K, model.cluster_num)

        eye = tf.eye(model.cluster_num)
        m = tf.exp(-cdist(model.discriminate, eye))
        self.DDC2 = d_cs(m, K, model.cluster_num)

        self.DDC3 = 2 / (model.cluster_num * (model.cluster_num - 1)) * triu(tf.transpose(model.discriminate) @ model.discriminate)

        self.DDC = self.DDC1 + self.DDC2 + self.DDC3

        if self.DDC_constraint:
            self.un_loss = self.kmeans_loss +  self.delta * self.DDC
        else:
            self.un_loss = self.kmeans_loss


        if self.constraint:
            self.mid_loss1 = self.pre_loss + self.alpha * self.softmax_loss
            self.mid_loss2 = self.mid_loss1 + self.beta * self.cross_entropy
            self.total_loss = self.mid_loss2 + self.gamma * self.un_loss
        else:
            self.mid_loss1 = self.pre_loss + self.alpha * self.softmax_loss
            self.total_loss = self.mid_loss1 + self.gamma * self.un_loss

        self.optimizer = tf.train.AdamOptimizer(self.learning_rate)  # 是Adam优化算法：是一个寻找全局最优点的优化算法，引入了二次方梯度校正
        self.pretrain_op = self.optimizer.minimize(self.pre_loss)  # 最小化损失函数
        if self.constraint:
            self.midtrain_op1 = self.optimizer.minimize(self.mid_loss1)
            self.midtrain_op2 = self.optimizer.minimize(self.mid_loss2)
        else:
            self.midtrain_op1 = self.optimizer.minimize(self.mid_loss1)
        self.train_op = self.optimizer.minimize(self.total_loss)