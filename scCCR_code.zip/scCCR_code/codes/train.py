
# -*- coding:utf-8 -*-
"""
作者：QinBaojuan
日期：2023年08月日
"""
import math
import random

import numpy as np

from optimizer import *
from preprocess import *
from sklearn.cluster import KMeans
import os
import time
from sklearn.metrics import adjusted_rand_score, accuracy_score, normalized_mutual_info_score
from collections import OrderedDict
import codecs
import csv
import pandas as pd


def label2matrix(label):
    unique_label, label = np.unique(label, return_inverse=True)
    one_hot_label = np.zeros((len(label), len(unique_label)))
    one_hot_label[np.arange(len(label)), label] = 1
    return one_hot_label

def cal_centers(repre, label):
    class_number = len(np.unique(label))#聚类簇的数量
    centers = np.zeros((class_number, repre.shape[1]))#训练数据集的聚类中心
    for i in range(class_number):
        centers[i] = np.mean(repre[label == i], axis=0)#求平均值
    return centers


def train(model, alpha, beta, gamma, delta, learning_rate, X, count_X, size_factor, cellname, batch_label, batch_size, random_seed, gpu_option):
    t1 = time.time()
    np.random.seed(random_seed)
    tf.set_random_seed(random_seed)

    optimizer = Optimizer(model, alpha, beta, gamma, delta, learning_rate, constraint=True, DDC_constraint=False)

    pretrain_epochs = 100
    # if optimizer.constraint:
    midtrain_epochs1 = 400
    midtrain_epochs2 = 500

    funetrain_epochs = 2000
    tol = 0.001

    cell_type, Y = np.unique(cellname, return_inverse=True)
    Y_train = Y[batch_label == 0]  # 训练数据2100，
    cellname_train = cellname[batch_label == 0]

    Y_test = Y[batch_label != 0]  # 测试数据4200
    cellname_test = cellname[batch_label != 0]

    label_vec = Y.astype(np.float32)
    mask_vec = batch_label - 1 + 1
    mask_vec[mask_vec != 0] = 1
    mask_vec = (1 - mask_vec).astype(np.float32)  # 批次掩码，训练数据为1，测试数据为0

    cluster_num_train = len(np.unique(Y_train))  # 训练数据簇的个数
    cluster_num_test = len(np.unique(Y_test))  # 测试数据簇的个数
    n_clusters = len(np.unique(Y))
    n_batches = len(np.unique(batch_label))
    cluster_num_overlap = cluster_num_train + cluster_num_test - n_clusters

    onehot_Y = label2matrix(Y)  # 热编码
    onehot_Y[batch_label != 0] = np.zeros((len(Y_test), n_clusters))  # 训练数据有标签，测试数据没有标签
    onehot_Y = onehot_Y.astype(np.float32)

    if X.shape[0] < batch_size:
        batch_size = X.shape[0]

    init = tf.group(tf.global_variables_initializer(), tf.local_variables_initializer())  # 创造一个操作，初始化模型参数
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # 按照PCI_BUS_ID顺序从0开始排列GPU设备
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_option  # 设置环境变量

    config_ = tf.ConfigProto()  # tf.ConfigProto()主要的作用是配置tf.Session的运算方式，比如gpu运算或者cpu运算
    config_.gpu_options.allow_growth = True  # 动态申请显存
    config_.allow_soft_placement = True  # 有时候，不同的设备，它的cpu和gpu是不同的，如果将这个选项设置成True，那么当运行设备不满足要求时，会自动分配GPU或者CPU(如果你指定的设备不存在，允许TF自动分配设备)
    sess = tf.Session(config=config_)
    sess.run(init)

    latent_repre = np.zeros((X.shape[0], model.dims[-1]))  # latent_repre的shape为【6300，32】，所有样本的潜在空间
    iteration_per_epoch = math.ceil(float(len(X)) / float(batch_size))  # 大于等于参数x的最小整数,即对浮点数向上取整.


    print("去噪损失：")
    for i in range(pretrain_epochs):  # 训练去噪损失
        print(i)
        for j in range(iteration_per_epoch):
            batch_idx = random.sample(range(X.shape[0]), batch_size)  # 从序列0-6299中选择256个随机且独立的元素
            _, latent, likeli = sess.run(  # 对于sess.sun(fetch), 只有fetch里的图元素, 才会被执行, 不在fetch中的图节点是不会执行的
                [optimizer.pretrain_op, model.latent, optimizer.pre_loss],  # feed_dict参数的作用是替换图中的某个tensor的值或设置graph的输入值。
                feed_dict={
                    model.sf_layer: size_factor[batch_idx],
                    model.x: X[batch_idx],
                    model.y: onehot_Y[batch_idx],
                    model.x_count: count_X[batch_idx],
                    model.label_vec: label_vec[batch_idx],
                    model.mask_vec: mask_vec[batch_idx]})
            latent_repre[batch_idx] = latent


    print("有标签损失：")
    for i in range(midtrain_epochs1):  # 去噪，训练带标签数据进行聚类
        print(i + 100)
        for j in range(iteration_per_epoch):
            batch_idx = random.sample(range(X.shape[0]), batch_size)  # 从序列0-6299中选择256个随机且独立的元素
            _, latent, likeli, softmax, entropy, p, q = sess.run(
                [optimizer.midtrain_op1, model.latent, optimizer.pre_loss, optimizer.softmax_loss, optimizer.cross_entropy,
                 model.discriminate, model.y],
                feed_dict={
                    model.sf_layer: size_factor[batch_idx],
                    model.x: X[batch_idx],
                    model.y: onehot_Y[batch_idx],
                    model.x_count: count_X[batch_idx],
                    model.label_vec: label_vec[batch_idx],
                    model.mask_vec: mask_vec[batch_idx]})
            latent_repre[batch_idx] = latent


    if optimizer.constraint:
        print("成对约束：")
        for i in range(midtrain_epochs2):  # 去噪，训练带标签数据进行聚类，并加上成对约束
            print(i + 500)
            for j in range(iteration_per_epoch):
                batch_idx = random.sample(range(X.shape[0]), batch_size)
                _, latent = sess.run(
                    [optimizer.midtrain_op2, model.latent],
                    feed_dict={
                        model.sf_layer: size_factor[batch_idx],
                        model.x: X[batch_idx],
                        model.y: onehot_Y[batch_idx],
                        model.x_count: count_X[batch_idx],
                        model.label_vec: label_vec[batch_idx],
                        model.mask_vec: mask_vec[batch_idx]})
                latent_repre[batch_idx] = latent


    if optimizer.gamma == 0.:
        dist, discrimin, kmeans_loss = sess.run(
            [optimizer.latent_dist1, model.discriminate, optimizer.kmeans_loss],  # 聚类中心，判别器，无标签损失（无优化器）
            feed_dict={
                model.sf_layer: size_factor,
                model.x: X,
                model.y: onehot_Y,
                model.x_count: count_X,
                model.label_vec: label_vec,
                model.mask_vec: mask_vec})
        Y_pred = np.argmax(discrimin, axis=1)  # np.argmax()是numpy中获取array的某一个维度中数值最大的那个元素的索引
        Y_pred1 = np.argmin(dist, axis=1)
        Y_pred_train = Y_pred[batch_label == 0]  # 训练预测值
        Y_pred_test = Y_pred[batch_label != 0]  # 测试预测值
        test_ARI = np.around(adjusted_rand_score(Y_test, Y_pred_test),
                             4)  # np.around()函数对输入浮点数执行5舍6入，5做特殊处理（小数点最后一位为5的舍入为与其值最接近的偶数值）

        acc = accuracy_score(Y_test, Y_pred_test)
        acc1 = accuracy_score(Y_test, Y_pred1[batch_label != 0])
        test_ARI1 = np.around(adjusted_rand_score(Y_test, Y_pred1[batch_label != 0]), 4)

    else:
        latent_repre = np.nan_to_num(
            latent_repre)  # 使用0代替数组x中的nan元素，使用有限的数字代替inf元素(默认行为)或者用户使用nan、posinf和neginf关键字来定义数字
        kmeans = KMeans(n_clusters=n_clusters, init="k-means++")  # Kmeans聚类
        kmeans_pred = kmeans.fit_predict(
            latent_repre)  # 计算每个样本的聚类中心并预测聚类指数， 计算簇的中心并且预测每个样本对应的簇类别，相当于先调用fit(X)再调用predict(X)，提倡这种方法，返回labels标签
        kmeans_pred_test = kmeans_pred[batch_label == 1]  # 得到测试数据集的每个样本的聚类中心并预测聚类指数
        last_pred_test = np.copy(kmeans_pred_test)
        latent_repre_train = latent_repre[batch_label == 0]  # 得到训练数据集的每个样本的聚类中心并预测聚类指数
        cluster_centers = cal_centers(latent_repre_train, Y_train)  # 计算聚类中心
        sess.run(tf.assign(model.clusters, cluster_centers))  # 聚类中心赋值
        print("无标签损失：")
        for i in range(funetrain_epochs):
            print(i + 1000)
            if (i + 1) % 10 != 0:  # 当i不是10的倍数
                for j in range(iteration_per_epoch):
                    batch_idx = random.sample(range(X.shape[0]), batch_size)
                    _, Kmeans_loss, latent, preloss, softloss, crossloss, DDC = sess.run(
                        [optimizer.train_op, optimizer.kmeans_loss, model.latent, optimizer.pre_loss, optimizer.softmax_loss, optimizer.cross_entropy, optimizer.DDC],  # 优化总损失
                        feed_dict={
                            model.sf_layer: size_factor[batch_idx],
                            model.x: X[batch_idx],
                            model.y: onehot_Y[batch_idx],
                            model.x_count: count_X[batch_idx],
                            model.label_vec: label_vec[batch_idx],
                            model.mask_vec: mask_vec[batch_idx]})
                    latent_repre[batch_idx] = latent


            else:  # 当i是10的倍数
                dist, discrimin, latent = sess.run(
                    [optimizer.latent_dist1, model.discriminate,  model.latent],  # 聚类中心，判别器，无标签数据的损失
                    feed_dict={
                        model.sf_layer: size_factor,
                        model.x: X,
                        model.y: onehot_Y,
                        model.x_count: count_X,
                        model.label_vec: label_vec,
                        model.mask_vec: mask_vec})
                latent_repre = latent
                latent_repre_train = latent_repre[batch_label == 0]  # 得到训练数据集的每个样本的聚类中心并预测聚类指数
                cluster_centers = cal_centers(latent_repre_train, Y_train)  # 计算聚类中心
                sess.run(tf.assign(model.clusters, cluster_centers))  # 聚类中心赋值
                Y_pred = np.argmin(dist, axis=1)  # 求最小值对应的索引,dist表示与聚类中心的聚类
                Y_pred_train = Y_pred[batch_label == 0]
                Y_pred_test = Y_pred[batch_label != 0]
                if np.sum(Y_pred_test != last_pred_test) / len(last_pred_test) < tol:  # 如果测试数据的聚类中心<0.01，则跳出循环
                    break
                else:
                    last_pred_test = Y_pred_test
            dist, discrimin = sess.run(
                [optimizer.latent_dist1, model.discriminate],  # 聚类中心，判别器，无标签损失（无优化器）
                feed_dict={
                    model.sf_layer: size_factor,
                    model.x: X,
                    model.y: onehot_Y,
                    model.x_count: count_X,
                    model.label_vec: label_vec,
                    model.mask_vec: mask_vec})

    sess.close()

    # adjusted_rand_score计算调整兰德指数ARI
    test_ARI = np.around(adjusted_rand_score(Y_test, Y_pred_test), 4)  # np.around()函数对输入浮点数执行5舍6入，5做特殊处理（小数点最后一位为5的舍入为与其值最接近的偶数值）
    annotated_train_accuracy, annotated_test_accuracy, test_annotation_label = annotation(cellname_train, cellname_test,
                                                                                          Y_pred_train, Y_pred_test)

    test_prediction_matrix = pd.DataFrame(
        {"true label": Y_test, "true cell type": cellname_test, "cluster label": Y_pred_test,
         "annotation cell type": test_annotation_label})
    mid = pd.DataFrame(latent_repre)
    mid.to_csv('./simulation_latent.csv', header=False, index=False)
    t2 = time.time()
    print("The total consuming time for the whole model training is {}".format(t2 - t1))
    return annotated_test_accuracy, test_ARI, test_prediction_matrix, latent_repre