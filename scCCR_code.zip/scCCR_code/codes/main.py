# -*- coding:utf-8 -*-
"""
作者：QinBaojuan
日期：2023年08月日
"""
from train import *
from model import *
from preprocess import *


if __name__ == "__main__":

    random_seed = 8888
    gpu_option = "0"
    aplha = 0.001
    beta = 0.1
    gamma = 0.1
    delta = 1
    # 读取数据
    dataname = "smaller_imbalance_7/splatter_simulate_data1.h5"
    X, Y, batch_label = read_simu(dataname)  # X表示细胞基因表达矩阵，Y表示细胞类型，batch_label表示批次
    Y = Y.astype(np.int)  # 将细胞类型的数据类型转换为int


    name = "scCC"
    cellname = np.array(["group" + str(i) for i in Y])  # 细胞簇名称
    dims = [1000, 256, 64, 32]  # 维度
    batch_size = 128  # 批次大小
    highly_genes = 1000  # 高表达基因数量
    count_X = X
    if X.shape[1] == highly_genes:  # 如果细胞样本中基因数量如高表达基因数量相同，则将highly_genes置为空
        highly_genes = None
    print("begin the data proprocess")
    # 数据预处理
    adata = sc.AnnData(X)  # scanpy中常见的数据结构是AnnData，它是一个用于存储数据的对象，
    adata.obs["celltype"] = cellname  # adata.obs	观测量	pandas Dataframe
    adata.obs["batch"] = batch_label  # 批次标签
    adata = normalize(adata, highly_genes=highly_genes, size_factors=True, normalize_input=True,
                      logtrans_input=True)  # 标准化
    X = adata.X.astype(np.float32)  # 将adata.X赋值给X，并转换数据类型为float32
    cellname = np.array(adata.obs["celltype"])
    batch_label = np.array(adata.obs["batch"])

    if highly_genes != None:
        high_variable = np.array(adata.var.highly_variable.index, dtype=np.int)  # 将高变基因的下标赋值给 high_variable
        count_X = count_X[:, high_variable]  # 获取只有特异基因的数据集
    else:
        select_genes = np.array(adata.var.index, dtype=np.int)
        select_cells = np.array(adata.obs.index, dtype=np.int)
        count_X = count_X[:, select_genes]
        count_X = count_X[select_cells]
    assert X.shape == count_X.shape
    size_factor = np.array(adata.obs.size_factors).reshape(-1, 1).astype(
        np.float32)  # 将adata.obs.size_factors转换为列向量并赋值给size_factor

    result = []

    cluster_num = len(np.unique(cellname))  # 簇数
    batch_num = len(np.unique(batch_label))  # 批次数
    tf.reset_default_graph()  # 清除默认图形堆栈并重置全局默认图形
    model = scCCR(name, dataname, dims, cluster_num)
    annotated_target_accuracy, target_ARI, target_prediction_matrix, latent_representation = train(model,
                                                                                                   aplha,
                                                                                                   beta,
                                                                                                   gamma,
                                                                                                   delta,
                                                                                                   1e-5,
                                                                                                   X,
                                                                                                   count_X,
                                                                                                   size_factor,
                                                                                                   cellname,
                                                                                                   batch_label,
                                                                                                   batch_size,
                                                                                                   random_seed,
                                                                                                   gpu_option)
    print("Under this setting, for target data, the clustering ARI is {}".format(target_ARI))
    print(
        "Under this setting, for target data, the annotation accuracy is {}".format(
            annotated_target_accuracy))


