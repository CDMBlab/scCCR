from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import h5py
import scanpy as sc
from sklearn.metrics.cluster import contingency_matrix
import anndata

def read_real1(filename):
    adata = anndata.read(filename)
    mat= adata.X
    if isinstance(mat, np.ndarray):
        X = np.array(mat)
    else:
        X = np.array(mat.toarray())
    obs = adata.obs
    cell_name = np.array(obs["cell_ontology_class"])
    if (cell_name == "").sum() > 0:
        cell_name[cell_name == ""] = "unknown_class"
    return X, cell_name

def read_real2(filename):
    adata = anndata.read(filename)
    mat= adata.X
    if isinstance(mat, np.ndarray):
        X = np.array(mat)
    else:
        X = np.array(mat.toarray())
    obs = adata.obs
    cell_name = np.array(obs["cell_ontology_class"])
    if (cell_name == "").sum() > 0:
        cell_name[cell_name == ""] = "unknown_class"

    var_name = adata.var_names
    genes_name = np.array(var_name)
    return X, cell_name, genes_name

def read_simu(dataname):
    data_path = "./data/simulation/" + dataname
    data_mat = h5py.File(data_path)
    x = np.array(data_mat["X"])
    y = np.array(data_mat["Y"])
    batch = np.array(data_mat["B"])
    return x, y, batch


def normalize(adata, highly_genes = None, size_factors=True, normalize_input=True, logtrans_input=True):
    #过滤低质量细胞样本：过滤在少于10个细胞中表达，或一个细胞中表达少于1个基因的细胞样本
    sc.pp.filter_genes(adata, min_counts=10)#过滤基因，在少于10个细胞样本上表达的基因
    sc.pp.filter_cells(adata, min_counts=1)#过滤细胞，少于1个表达基因的细胞
    if size_factors or normalize_input or logtrans_input:#size_factors文库大小：每一个细胞所有基因表达量的总和。
        #判断输入数据是否经过文库大小标准化或标准化或log转换
        adata.raw = adata.copy()    #存储数据，如果不想adata.X里面的值修改，就使用copy()
    else:
        adata.raw = adata   #保存原始数据

    if size_factors:
        sc.pp.normalize_per_cell(adata) #通过所有基因的总数对每个细胞进行归一化，以便每个细胞都有规范化后的总数相同。
        adata.obs['size_factors'] = adata.obs.n_counts / np.median(adata.obs.n_counts)  #每个细胞的大小因子
    else:
        adata.obs['size_factors'] = 1.0

    if logtrans_input:
        sc.pp.log1p(adata)  # 对数化

    if highly_genes != None:
        # # 去除重复的基因名称
        # adata.var_names = pd.unique(adata.var_names)

        sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5, n_top_genes = highly_genes, subset=True)  #识别特异基因，确定高变基因；在细胞与细胞间进行比较，选择表达量差别最大的基因。data：AnnData Matrix，行对应细胞，列对应基因
                                                                                                                     #n_top_genes：要保留的高变基因的数量

    if normalize_input:
        sc.pp.scale(adata)  #将每个基因缩放到单位方差

    return adata

#细胞类型注释
def annotation(cellname_train, cellname_test, Y_pred_train, Y_pred_test):
    train_confusion_matrix = contingency_matrix(cellname_train, Y_pred_train)#权变矩阵，实际到预测的集群的非最高对角线排序，可能性矩阵(sklearn.metrics.cluster.contingency_matrix）报告每个真/预测集群对的交集基数。列联矩阵为所有聚类指标提供了足够的统计信息，其中示例是独立且相同分布的，并且不需要考虑某些没有聚集的实例
    annotated_cluster = np.unique(Y_pred_train)[train_confusion_matrix.argmax(axis=1)]
    annotated_celltype = np.unique(cellname_train)
    annotated_score = np.max(train_confusion_matrix, axis=1) / np.sum(train_confusion_matrix, axis=1)#最大值除以总和，注释分数
    annotated_celltype[(np.max(train_confusion_matrix, axis=1) / np.sum(train_confusion_matrix, axis=1)) < 0.5] = "unassigned"
    final_annotated_cluster = []#注释簇
    final_annotated_celltype = []#注释细胞类型
    for i in np.unique(annotated_cluster):
        candidate_celltype = annotated_celltype[annotated_cluster == i]
        candidate_score = annotated_score[annotated_cluster == i]
        final_annotated_cluster.append(i)
        final_annotated_celltype.append(candidate_celltype[np.argmax(candidate_score)])
    annotated_cluster = np.array(final_annotated_cluster)
    annotated_celltype = np.array(final_annotated_celltype)

    succeed_annotated_train = 0
    succeed_annotated_test = 0
    test_annotation_label = np.array(["original versions for unassigned cell ontology types"] * len(cellname_test))
    for i in range(len(annotated_cluster)):
        succeed_annotated_train += (cellname_train[Y_pred_train == annotated_cluster[i]] == annotated_celltype[i]).sum()
        succeed_annotated_test += (cellname_test[Y_pred_test == annotated_cluster[i]] == annotated_celltype[i]).sum()
        test_annotation_label[Y_pred_test == annotated_cluster[i]] = annotated_celltype[i]
    annotated_train_accuracy = np.around(succeed_annotated_train / len(cellname_train), 4)#np.around()函数用于返回五舍六入后的值，可指定精度。
    total_overlop_test = 0
    for celltype in np.unique(cellname_train):
        total_overlop_test += (cellname_test == celltype).sum()
    annotated_test_accuracy = np.around(succeed_annotated_test / total_overlop_test, 4)
    test_annotation_label[test_annotation_label == "original versions for unassigned cell ontology types"] = "unassigned"
    return annotated_train_accuracy, annotated_test_accuracy, test_annotation_label